import fs from 'fs/promises';
import path from 'path';

export async function exportJobs(jobs) {
  const outDir = path.resolve(process.cwd(), 'output');
  await fs.mkdir(outDir, { recursive: true });
  const jsonPath = path.join(outDir, 'jobs.json');
  const csvPath = path.join(outDir, 'jobs.csv');

  // Write JSON
  await fs.writeFile(jsonPath, JSON.stringify(jobs, null, 2), 'utf-8');

  // CSV headers (stable order)
  const headers = [
    'jobId',
    'jobTitle',
    'companyName',
    'location',
    'salary_min',
    'salary_max',
    'salary_currency',
    'salary_period',
    'employmentType',
    'seniority',
    'tags',
    'postedAt',
    'jobUrl',
    'companyUrl',
    'description',
  ];

  const lines = [headers.join(',')];

  for (const job of jobs) {
    const s = job.salary || {};
    const cols = [
      job.jobId || '',
      job.jobTitle || '',
      job.companyName || '',
      job.location || '',
      s.min != null ? String(s.min) : '',
      s.max != null ? String(s.max) : '',
      s.currency || '',
      s.period || '',
      job.employmentType || '',
      job.seniority || '',
      Array.isArray(job.tags) ? job.tags.join('|') : '',
      job.postedAt || '',
      job.jobUrl || '',
      job.companyUrl || '',
      job.description ? job.description.replace(/\r?\n/g, ' ') : '',
    ];
    lines.push(cols.map(escapeCsv).join(','));
  }

  await fs.writeFile(csvPath, lines.join('\n'), 'utf-8');
  console.log(`[exportJobs] Exported ${jobs.length} jobs to ${jsonPath} and ${csvPath}`);
}

function escapeCsv(v) {
  if (v == null) return '';
  const s = String(v).replace(/"/g, '""');
  if (s.includes(',') || s.includes('"') || s.includes('\n')) return `"${s}"`;
  return s;
}
