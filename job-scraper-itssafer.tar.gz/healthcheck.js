// Simple healthcheck script
const fs = require('fs');
const { exec } = require('child_process');

// Check if Node.js process is running and responsive
exec('ps aux | grep "[n]ode"', (error, stdout, stderr) => {
    if (error) {
        console.error('Error checking Node process:', error);
        process.exit(1);
    }

    // Check if output directory is writable
    try {
        fs.accessSync('/app/output', fs.constants.W_OK);
        process.exit(0);
    } catch (err) {
        console.error('Output directory not writable:', err);
        process.exit(1);
    }
});